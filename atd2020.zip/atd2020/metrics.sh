#!/bin/bash

python -m atd2020.metrics -p results/City_1.csv -t data/City_1.parquet.brotli -g Fraction_Observed
